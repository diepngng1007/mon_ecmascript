export default function NavigaAdmin (){
    return ` 
    <div class="templete_main">
        <div class="templete_navbar">
            <div class="templete_logo"><p style="font-size: 45px;text-align: center;">Admin</p></div>
            <div>
                <ul>
                    <li><a href="#">Quản lý tài khoản</a></li>
                    <li><a href="/admin/product">Quản lý sản phẩm</a></li>
                    <li><a href="/admin/category">Quản lý danh mục</a></li>
                </ul>
            </div>
        </div>
        <div class="templete_content">
            <div class="content">

            </div>
        </div>

</div>`
}